﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cosmetics.Contracts;
using Cosmetics.Common;
namespace Cosmetics.Categories
{
    public class Categories : ICategory
    { private const int MinNameLenght = 2;
        private const int MaxNameLength = 15;
        private string name;
        private ICollection<IProduct> category;
        public Categories(string name, ICollection<IProduct> cat)
        {
            this.Name = name;
            this.CategoryList = cat;
        }
        public Categories(string name)
        {
            this.Name = name;
            this.CategoryList = new List<IProduct>();
        }
       
        public string Name
        {
            get
            {
                return this.name;
            }
         private   set
            {
                Validator.CheckIfStringLengthIsValid(value, MaxNameLength, MinNameLenght,
                    String.Format(GlobalErrorMessages.InvalidStringLength, this.GetType().Name + " name", MinNameLenght, MaxNameLength));

                this.name = value;
                
            }
        }
        public ICollection<IProduct> CategoryList { get { return this.category; } private set { this.category = value; } }
        public Categories(string n,List<IProduct>categori)
        {
            this.Name = n;
            this.CategoryList = categori;
        }
        public void AddCosmetics(IProduct cosmetics)
        {
            this.CategoryList.Add(cosmetics);
        }

        public string Print()
        {
            StringBuilder result = new StringBuilder();
            result.AppendLine(String.Format("{0} category - {1} {2} in total", this.Name, this.CategoryList.Count, this.CategoryList.Count == 1 ? "product" : "products"));
            foreach (var product in this.CategoryList)
            {
                result.AppendLine(product.Print());
            }
            return result.ToString();
        }

        public void RemoveCosmetics(IProduct cosmetics)
        {
            if (!this.CategoryList.Contains(cosmetics))
            {
                throw new ArgumentException(String.Format("Product {product name} does not exist in category {category name}!", cosmetics.Name, this.Name));
            }
            this.CategoryList.Remove(cosmetics);
        }
    }
}
