﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cosmetics.Common;
using Cosmetics.Contracts;
namespace Cosmetics.Products
{
    public class Toothpaste :Product ,IToothpaste, IProduct

    {
        public Toothpaste(string name, string brand, decimal price, GenderType gender,IList<string> ingre):base(name, brand, price, gender)
        {
            foreach (var item in ingre)
            {
                Validator.CheckIfStringLengthIsValid(item, 15, 2, (String.Format("Each ingredient must be between {0} and {1} symbols long!", 2, 15)));
            }
            this.Ingredients = String.Join(", ", ingre);
        }
        private string ingredien;
        

        public string Ingredients
        {
            get { return this.ingredien; }
            private set
            {
                Validator.CheckIfStringIsNullOrEmpty(value, GlobalErrorMessages.ObjectCannotBeNull);
                var checker = value.Split(new char[] { ' ', ',' },StringSplitOptions.RemoveEmptyEntries).ToList();
                foreach (var item in checker)
                {

                }
                this.ingredien = value;
            }
        }

     

        public override string Print()
        {
            StringBuilder result = new StringBuilder();
            result.Append(base.Print());
            result.AppendLine(String.Format("* Ingredients:  {0}", this.Ingredients));
           
            return result.ToString();

        }
    }
}
