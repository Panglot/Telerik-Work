﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cosmetics.Common;
using Cosmetics.Contracts;
namespace Cosmetics.Products
{
    public  class Product : IProduct
    { private const int minNameLength = 2;
        private const int maxNameLength = 10;
        private const int minBrandLength = 3;
        private const int maxBrandLength = 15;
        private string name;
        private GenderType gender;
        private string brand;
        private decimal price;
        public Product(string na,string br ,decimal pr,GenderType gen)
        {
            this.Name = na;
            this.Brand = br;
            this.Price = pr;
            this.Gender = gen;
        }
        public string Brand
        {
            get
            {
                return this.brand;
            }
            protected set
            {
                Validator.CheckIfStringIsNullOrEmpty(value, GlobalErrorMessages.ObjectCannotBeNull);
                Validator.CheckIfStringLengthIsValid(value, maxBrandLength, minBrandLength, String.Format("Product brand must be between {0} and {1} symbols long!", minNameLength, maxNameLength));
                this.brand = value;
            }
        }

        public GenderType Gender
        {
            get; private set;
        }

        public string Name
        {
            get
            {
                return this.name;
            }
            set
            {
                Validator.CheckIfStringIsNullOrEmpty(value, GlobalErrorMessages.ObjectCannotBeNull);
                Validator.CheckIfStringLengthIsValid(value, maxNameLength, minNameLength, String.Format("Product name must be between {0} and {1} symbols long!", minNameLength, maxNameLength));
                this.name = value;
            }
        }

        public decimal Price
        {
            get
            {
                return this.price;
            }
            protected set
            {
                if (value < 0)
                {
                    throw new ArgumentException("Price cant be Negative value!");
                }
                this.price = value;
            }
        }

        public virtual string Print()
        {
            StringBuilder result = new StringBuilder();
            result.AppendLine(String.Format("- {0} – {1}:", this.Brand, this.Name));
            result.AppendLine(String.Format("*Price: ${0}", this.Price));
            result.AppendLine(String.Format("*For gender: {0}", this.Gender));
            return result.ToString();
        }
    }
}
